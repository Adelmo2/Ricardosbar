package com.ricardosbar.dto;

import com.ricardosbar.model.Cliente;

import java.time.LocalDateTime;

public record DadosDetalhamentoClienteDto(
        Long id,
        String nome,
        String telefone,
        String endereco,
        String bairro,
        String cidade,
        String uf,
        Double valor_ult_pagto,
        LocalDateTime dt_ult_pago,
        String hora_ult_pago,
        Double saldo_pagar,
        LocalDateTime primeira_compra,
        Double limite,
        Boolean bloqueado,
        String observacao,
        String email
)
{
    public DadosDetalhamentoClienteDto(Cliente cliente) {
        this(cliente.getId(),
                cliente.getNome(),
                cliente.getTelefone(),
                cliente.getEndereco(),
                cliente.getBairro(),
                cliente.getCidade(),
                cliente.getUf(),
                cliente.getValor_ult_pagto(),
                cliente.getDt_ult_pago(),
                cliente.getHora_ult_pago(),
                cliente.getSaldo_pagar(),
                cliente.getPrimeira_compra(),
                cliente.getLimite(),
                cliente.getBloqueado(),
                cliente.getObservacao(),
                cliente.getEmail()
        );
    }
}
