package com.ricardosbar.service;

import com.ricardosbar.dto.DadosDetalhamentoVendaFullDto;
import com.ricardosbar.repository.ClienteRepository;
import com.ricardosbar.repository.ProdutoRepository;
import com.ricardosbar.validacoes.validacaoException;
import com.ricardosbar.repository.VendaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DadosDetalhamentoVendasService {

    private final VendaRepository vendaRepository;
    private final ClienteRepository clienteRepository;
    private final ProdutoRepository  produtoRepository;
    public DadosDetalhamentoVendasService(VendaRepository vendaRepository, ClienteRepository clienteRepository, ProdutoRepository produtoRepository) {
        this.vendaRepository = vendaRepository;
        this.clienteRepository = clienteRepository;
        this.produtoRepository = produtoRepository;
    }
//    public List<DadosDetalhamentoVendaDto> listaVendaDoCliente(Long id) {
//        List<Venda> vendas = vendaRepository.vendasPorCliente(id);
//        return vendas.stream()
//                .map(DadosDetalhamentoVendaDto::new)
//                .toList();
//    }

    public List<DadosDetalhamentoVendaFullDto> listaVendaDoCliente(Long id) {
        if (!clienteRepository.existsById(id)) {
            throw new validacaoException("Id do cliente informado não existe!");
        }
        return  vendaRepository.vendasPorCliente(id);
    }

    public List<DadosDetalhamentoVendaFullDto> listaVendaDoProduto(Long id) {
        if (!produtoRepository.existsById(id)) {
            throw new validacaoException("Id do produto informado não existe!");
        }
        return  vendaRepository.vendasPorProduto(id);
    }

}